import streamlit as st
import pandas as pd
from vanna_calls import (
    generate_sql_cached,
    run_sql_cached,
    generate_plotly_code_cached,
    generate_questions_cached
)

# Configurações do aplicativo Streamlit
st.set_page_config(
    page_title="Vanna Dashboard",
    page_icon=":bar_chart:",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Cabeçalho
st.title("Vanna Dashboard")
st.markdown("""
    <style>
        .main {background-color: #1E1E1E;}
        .sidebar .sidebar-content {background-color: #1E1E1E;}
        .css-1d391kg {color: white;}
    </style>
""", unsafe_allow_html=True)

# Função para exibir a consulta SQL e o DataFrame
def display_sql_and_df(question):
    sql = generate_sql_cached(question)
    if sql:
        df = run_sql_cached(sql)
        st.write("### Consulta SQL")
        st.code(sql, language='sql')
        st.write("### Resultado da Consulta")
        st.dataframe(df)
        return df
    else:
        st.write("Consulta SQL não encontrada.")

# Função para gerar e exibir o gráfico Plotly
def display_plotly_graph(question, df):
    plotly_code = generate_plotly_code_cached(question, df)
    if plotly_code:
        exec(plotly_code)  # Executa o código Plotly gerado

# Sidebar para seleção de perguntas
st.sidebar.header("Perguntas")
questions = generate_questions_cached()
selected_question = st.sidebar.selectbox("Escolha uma pergunta:", questions)

# Área principal do aplicativo
st.sidebar.header("Configurações")
show_sql = st.sidebar.checkbox("Mostrar SQL", value=True)
show_table = st.sidebar.checkbox("Mostrar Tabela", value=True)
show_plotly = st.sidebar.checkbox("Mostrar Gráfico", value=True)

if selected_question:
    if show_sql or show_table or show_plotly:
        df = display_sql_and_df(selected_question) if show_table else None
        if show_plotly and df is not None:
            display_plotly_graph(selected_question, df)

