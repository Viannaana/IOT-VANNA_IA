import openai
import jaydebeapi
import pandas as pd
import plotly.express as px
import json
import hashlib
from functools import lru_cache

# Defina a chave da API diretamente (não recomendado para produção)
openai.api_key = "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"

# Substitua esses valores pelos seus caminhos e credenciais corretos
JDBC_DRIVER_CLASS = 'oracle.jdbc.driver.OracleDriver'
JDBC_DRIVER_PATH = '/Users/anajuliavianna/Downloads/ojdbc8.jar'  # Caminho para o arquivo JAR do driver
DB_URL = 'jdbc:oracle:thin:@oracle.fiap.com.br:1521/orcl'  # URL de conexão do banco de dados
DB_USER = 'RM98974'  # Seu usuário do banco de dados
DB_PASSWORD = '100903'  # Sua senha do banco de dados

# Inicialize a conexão com o banco de dados
def init_db():
    return jaydebeapi.connect(JDBC_DRIVER_CLASS, DB_URL, [DB_USER, DB_PASSWORD], JDBC_DRIVER_PATH)

def hash_dataframe(df):
    """ Cria um hash para o DataFrame. """
    return hashlib.md5(json.dumps(df.to_dict(), sort_keys=True).encode()).hexdigest()

@lru_cache(maxsize=100)
def run_sql_cached(sql):
    """
    Executa o SQL fornecido e retorna o resultado como um DataFrame do Pandas.
    """
    conn = init_db()
    cursor = conn.cursor()
    try:
        cursor.execute(sql)
        df = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])
    finally:
        cursor.close()
        conn.close()
    return df

def generate_sql_with_openai(question):
    """
    Usa OpenAI para gerar a instrução SQL com base na pergunta fornecida.
    """
    response = openai.Completion.create(
        model="text-davinci-003",
        prompt=f"Converta a seguinte pergunta em uma instrução SQL:\n\nPergunta: {question}",
        max_tokens=150
    )
    sql = response.choices[0].text.strip()
    return sql

@lru_cache(maxsize=10)
def generate_sql_cached(question):
    """
    Gera a instrução SQL com base na pergunta fornecida.
    """
    sql_mapping = {
        "Qual é o total de vendas por mês deste ano?": """
            SELECT TO_CHAR(DATA_PEDIDO, 'YYYY-MM') AS MES, SUM(VALOR_TOTAL) AS TOTAL_VENDAS
            FROM Pedido
            WHERE EXTRACT(YEAR FROM DATA_PEDIDO) = EXTRACT(YEAR FROM SYSDATE)
            GROUP BY TO_CHAR(DATA_PEDIDO, 'YYYY-MM')
            ORDER BY MES
        """,
        "Qual é o valor médio de vendas por loja?": """
            SELECT L.NOME_LOJA, AVG(P.VALOR_TOTAL) AS VALOR_MEDIO
            FROM Pedido P
            JOIN Loja L ON P.LOJA_ID = L.ID
            GROUP BY L.NOME_LOJA
        """,
        "Quantos produtos há em estoque por tipo?": """
            SELECT T.TIPO_PRODUTO, COUNT(E.ID) AS QUANTIDADE
            FROM Estoque E
            JOIN (SELECT 'Blusa' AS TIPO_PRODUTO FROM dual UNION ALL
                  SELECT 'Calca' FROM dual UNION ALL
                  SELECT 'Saia' FROM dual UNION ALL
                  SELECT 'Acessorio' FROM dual UNION ALL
                  SELECT 'Bolsa' FROM dual UNION ALL
                  SELECT 'Perfume' FROM dual) T
            ON E.PRODUTO_ID = T.TIPO_PRODUTO
            GROUP BY T.TIPO_PRODUTO
        """,
        "Qual é o total de pedidos por vendedor?": """
            SELECT V.NOME_VENDEDOR, COUNT(P.ID) AS TOTAL_PEDIDOS
            FROM Pedido P
            JOIN Vendedor V ON P.VENDEDOR_ID = V.ID
            GROUP BY V.NOME_VENDEDOR
        """,
        "Qual é o total de vendas por cliente?": """
            SELECT C.NOME_CLIENTE, SUM(P.VALOR_TOTAL) AS TOTAL_VENDAS
            FROM Pedido P
            JOIN Cliente C ON P.CLIENTE_ID = C.ID
            GROUP BY C.NOME_CLIENTE
        """,
        "Qual é a quantidade total de produtos vendidos por tipo?": """
            SELECT T.TIPO_PRODUTO, SUM(PP.QUANTIDADE) AS QUANTIDADE_TOTAL
            FROM PedidoProduto PP
            JOIN (SELECT 'Blusa' AS TIPO_PRODUTO FROM dual UNION ALL
                  SELECT 'Calca' FROM dual UNION ALL
                  SELECT 'Saia' FROM dual UNION ALL
                  SELECT 'Acessorio' FROM dual UNION ALL
                  SELECT 'Bolsa' FROM dual UNION ALL
                  SELECT 'Perfume' FROM dual) T
            ON PP.PRODUTO_ID = T.TIPO_PRODUTO
            GROUP BY T.TIPO_PRODUTO
        """,
        "Qual é o total de pedidos cancelados e devolvidos?": """
            SELECT 'Cancelamento' AS TIPO, COUNT(ID) AS TOTAL
            FROM PedidoCancelamento
            UNION ALL
            SELECT 'Devolucao', COUNT(ID)
            FROM PedidoDevolucao
        """,
        "Qual é a quantidade de cada acessório em estoque?": """
            SELECT A.NOME_ACESSORIO, COUNT(E.ID) AS QUANTIDADE
            FROM Estoque E
            JOIN Acessorio A ON E.PRODUTO_ID = A.ID
            GROUP BY A.NOME_ACESSORIO
        """
    }
    return sql_mapping.get(question) or generate_sql_with_openai(question)

@lru_cache(maxsize=10)
def generate_plotly_code_cached(question, df):
    """
    Gera o código Plotly com base na pergunta e no DataFrame fornecidos.
    """
    plotly_mapping = {
        "Qual é o total de vendas por mês deste ano?": """
            fig = px.bar(df, x='MES', y='TOTAL_VENDAS', title='Total de Vendas por Mês deste Ano')
            fig.update_layout(xaxis_title='Mês', yaxis_title='Total de Vendas')
            fig.show()
        """,
        "Qual é o valor médio de vendas por loja?": """
            fig = px.bar(df, x='NOME_LOJA', y='VALOR_MEDIO', title='Valor Médio de Vendas por Loja')
            fig.update_layout(xaxis_title='Loja', yaxis_title='Valor Médio')
            fig.show()
        """,
        "Quantos produtos há em estoque por tipo?": """
            fig = px.bar(df, x='TIPO_PRODUTO', y='QUANTIDADE', title='Quantidade de Produtos em Estoque por Tipo')
            fig.update_layout(xaxis_title='Tipo de Produto', yaxis_title='Quantidade')
            fig.show()
        """,
        "Qual é o total de pedidos por vendedor?": """
            fig = px.bar(df, x='NOME_VENDEDOR', y='TOTAL_PEDIDOS', title='Total de Pedidos por Vendedor')
            fig.update_layout(xaxis_title='Vendedor', yaxis_title='Total de Pedidos')
            fig.show()
        """,
        "Qual é o total de vendas por cliente?": """
            fig = px.bar(df, x='NOME_CLIENTE', y='TOTAL_VENDAS', title='Total de Vendas por Cliente')
            fig.update_layout(xaxis_title='Cliente', yaxis_title='Total de Vendas')
            fig.show()
        """,
        "Qual é a quantidade total de produtos vendidos por tipo?": """
            fig = px.bar(df, x='TIPO_PRODUTO', y='QUANTIDADE_TOTAL', title='Quantidade Total de Produtos Vendidos por Tipo')
            fig.update_layout(xaxis_title='Tipo de Produto', yaxis_title='Quantidade Total')
            fig.show()
        """,
        "Qual é o total de pedidos cancelados e devolvidos?": """
            fig = px.pie(df, names='TIPO', values='TOTAL', title='Pedidos Cancelados e Devolvidos')
            fig.update_layout(title_text='Pedidos Cancelados e Devolvidos')
            fig.show()
        """,
        "Qual é a quantidade de cada acessório em estoque?": """
            fig = px.bar(df, x='NOME_ACESSORIO', y='QUANTIDADE', title='Quantidade de Cada Acessório em Estoque')
            fig.update_layout(xaxis_title='Acessório', yaxis_title='Quantidade')
            fig.show()
        """
    }
    return plotly_mapping.get(question)

@lru_cache(maxsize=10)
def generate_questions_cached():
    """
    Gera uma lista de perguntas sugeridas para o usuário.
    """
    return [
        "Qual é o total de vendas por mês deste ano?",
        "Qual é o valor médio de vendas por loja?",
        "Quantos produtos há em estoque por tipo?",
        "Qual é o total de pedidos por vendedor?",
        "Qual é o total de vendas por cliente?",
        "Qual é a quantidade total de produtos vendidos por tipo?",
        "Qual é o total de pedidos cancelados e devolvidos?",
        "Qual é a quantidade de cada acessório em estoque?"
    ]
