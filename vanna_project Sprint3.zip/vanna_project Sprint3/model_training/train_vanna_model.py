import jaydebeapi
import jpype
from vanna.remote import VannaDefault
from vanna.flask import VannaFlaskApp

# Configurações do Banco de Dados
jdbc_driver_loc = "/Users/anajuliavianna/Downloads/ojdbc8.jar"
jdbc_driver_name = "oracle.jdbc.driver.OracleDriver"
jdbc_url = "jdbc:oracle:thin:@oracle.fiap.com.br:1521/orcl"
user = "RM98974"
password = "100903"

# Inicializa a JVM
jpype.startJVM(jpype.getDefaultJVMPath(), "-Djava.class.path=" + jdbc_driver_loc)

# Conecta ao banco de dados
conn = jaydebeapi.connect(jdbc_driver_name, jdbc_url, [user, password], jdbc_driver_loc)
curs = conn.cursor()

# DDL Completo
ddl = """
    CREATE TABLE Endereco (
        ID_ENDERECO NUMBER PRIMARY KEY,
        RUA VARCHAR2(100),
        NUMERO VARCHAR2(10),
        COMPLEMENTO VARCHAR2(50),
        BAIRRO VARCHAR2(50),
        CIDADE VARCHAR2(50),
        ESTADO VARCHAR2(2),
        CEP VARCHAR2(10)
    );
    CREATE TABLE Loja (
        ID_LOJA NUMBER PRIMARY KEY,
        NOME_LOJA VARCHAR2(100),
        ENDERECO NUMBER,
        FOREIGN KEY (ENDERECO) REFERENCES Endereco(ID_ENDERECO)
    );
    CREATE TABLE Cliente (
        ID_CLIENTE NUMBER PRIMARY KEY,
        NOME_CLIENTE VARCHAR2(100),
        EMAIL VARCHAR2(100),
        TELEFONE VARCHAR2(15),
        ENDERECO NUMBER,
        FOREIGN KEY (ENDERECO) REFERENCES Endereco(ID_ENDERECO)
    );
    CREATE TABLE Vendedor (
        ID_VENDEDOR NUMBER PRIMARY KEY,
        NOME_VENDEDOR VARCHAR2(100),
        EMAIL VARCHAR2(100),
        TELEFONE VARCHAR2(15)
    );
    CREATE TABLE Pedido (
        ID_PEDIDO NUMBER PRIMARY KEY,
        DATA_PEDIDO DATE,
        VALOR_TOTAL NUMBER,
        ID_CLIENTE NUMBER,
        ID_LOJA NUMBER,
        ID_VENDEDOR NUMBER,
        TIPO_PEDIDO VARCHAR2(50),
        FOREIGN KEY (ID_CLIENTE) REFERENCES Cliente(ID_CLIENTE),
        FOREIGN KEY (ID_LOJA) REFERENCES Loja(ID_LOJA),
        FOREIGN KEY (ID_VENDEDOR) REFERENCES Vendedor(ID_VENDEDOR)
    );
    CREATE TABLE Estoque (
        ID_ESTOQUE NUMBER PRIMARY KEY,
        TIPO_PRODUTO VARCHAR2(50),
        QUANTIDADE NUMBER,
        ID_LOJA NUMBER,
        FOREIGN KEY (ID_LOJA) REFERENCES Loja(ID_LOJA)
    );
    CREATE TABLE PEDIDOPRODUTO (
        ID_PEDIDO NUMBER,
        TIPO_PRODUTO VARCHAR2(50),
        QUANTIDADE NUMBER,
        FOREIGN KEY (ID_PEDIDO) REFERENCES Pedido(ID_PEDIDO)
    );
    CREATE TABLE PedidoCancelamento (
        ID_CANCELAMENTO NUMBER PRIMARY KEY,
        ID_PEDIDO NUMBER,
        FOREIGN KEY (ID_PEDIDO) REFERENCES Pedido(ID_PEDIDO)
    );
    CREATE TABLE PedidoDevolucao (
        ID_DEVOLUCAO NUMBER PRIMARY KEY,
        ID_PEDIDO NUMBER,
        FOREIGN KEY (ID_PEDIDO) REFERENCES Pedido(ID_PEDIDO)
    );
    CREATE TABLE PedidoReembolso (
        ID_REEMBOLSO NUMBER PRIMARY KEY,
        ID_PEDIDO NUMBER,
        FOREIGN KEY (ID_PEDIDO) REFERENCES Pedido(ID_PEDIDO)
    );
"""

# Consultas SQL
sql_mapping = {
    "Qual é o total de vendas por mês deste ano?": """
        SELECT TO_CHAR(DATA_PEDIDO, 'YYYY-MM') AS MES, SUM(VALOR_TOTAL) AS TOTAL_VENDAS
        FROM Pedido
        WHERE EXTRACT(YEAR FROM DATA_PEDIDO) = EXTRACT(YEAR FROM SYSDATE)
        GROUP BY TO_CHAR(DATA_PEDIDO, 'YYYY-MM')
        ORDER BY MES
    """,
    "Qual é o valor médio das vendas por loja?": """
        SELECT l.NOME_LOJA, AVG(p.VALOR_TOTAL) AS VALOR_MEDIO_VENDA
        FROM Pedido p
        JOIN Loja l ON p.ID_LOJA = l.ID_LOJA
        GROUP BY l.NOME_LOJA
        ORDER BY VALOR_MEDIO_VENDA DESC
    """,
    "Qual é a quantidade total de produtos em estoque por tipo?": """
        SELECT TIPO_PRODUTO, SUM(QUANTIDADE) AS TOTAL_ESTOQUE
        FROM Estoque
        GROUP BY TIPO_PRODUTO
        ORDER BY TOTAL_ESTOQUE DESC
    """,
    "Qual é o total de pedidos e o valor total de vendas por vendedor?": """
        SELECT v.NOME_VENDEDOR, COUNT(p.ID_PEDIDO) AS NUM_PEDIDOS, SUM(p.VALOR_TOTAL) AS TOTAL_VENDAS
        FROM Pedido p
        JOIN Vendedor v ON p.ID_VENDEDOR = v.ID_VENDEDOR
        GROUP BY v.NOME_VENDEDOR
        ORDER BY TOTAL_VENDAS DESC
    """,
    "Qual é o valor total das vendas e o número de pedidos por tipo de pedido?": """
        SELECT TIPO_PEDIDO, COUNT(ID_PEDIDO) AS NUM_PEDIDOS, SUM(VALOR_TOTAL) AS VALOR_TOTAL
        FROM Pedido
        GROUP BY TIPO_PEDIDO
        ORDER BY VALOR_TOTAL DESC
    """,
    "Qual é o total de vendas por loja?": """
        SELECT l.NOME_LOJA, SUM(p.VALOR_TOTAL) AS TOTAL_VENDAS
        FROM Pedido p
        JOIN Loja l ON p.ID_LOJA = l.ID_LOJA
        GROUP BY l.NOME_LOJA
        ORDER BY TOTAL_VENDAS DESC
    """,
    "Qual é o total de vendas por cliente?": """
        SELECT c.NOME_CLIENTE, SUM(p.VALOR_TOTAL) AS TOTAL_VENDAS
        FROM Pedido p
        JOIN Cliente c ON p.ID_CLIENTE = c.ID_CLIENTE
        GROUP BY c.NOME_CLIENTE
        ORDER BY TOTAL_VENDAS DESC
    """,
    "Qual é a quantidade total vendida de cada produto?": """
        SELECT TIPO_PRODUTO, SUM(QUANTIDADE) AS TOTAL_VENDIDO
        FROM PEDIDOPRODUTO
        GROUP BY TIPO_PRODUTO
        ORDER BY TOTAL_VENDIDO DESC
    """,
    "Qual é o número total de pedidos por tipo de produto?": """
        SELECT e.TIPO_PRODUTO, COUNT(p.ID_PEDIDO) AS NUM_PEDIDOS
        FROM Pedido p
        JOIN Estoque e ON p.ID_LOJA = e.ID_LOJA
        GROUP BY e.TIPO_PRODUTO
        ORDER BY NUM_PEDIDOS DESC
    """,
    "Qual é o total de pedidos cancelados, devolvidos e reembolsos por vendedor?": """
        SELECT v.NOME_VENDEDOR,
               COUNT(DISTINCT pc.ID_CANCELAMENTO) AS NUM_CANCELAMENTOS,
               COUNT(DISTINCT pd.ID_DEVOLUCAO) AS NUM_DEVOLUCOES,
               COUNT(DISTINCT pr.ID_REEMBOLSO) AS NUM_REEMBOLSOS
        FROM Vendedor v
        LEFT JOIN PedidoCancelamento pc ON v.ID_VENDEDOR = pc.ID_PEDIDO
        LEFT JOIN PedidoDevolucao pd ON v.ID_VENDEDOR = pd.ID_PEDIDO
        LEFT JOIN PedidoReembolso pr ON v.ID_VENDEDOR = pr.ID_PEDIDO
        GROUP BY v.NOME_VENDEDOR
        ORDER BY NUM_REEMBOLSOS DESC, NUM_DEVOLUCOES DESC, NUM_CANCELAMENTOS DESC
    """
}

# Inicializa o Vanna
vn = VannaDefault(model='ntjtech', api_key='4261a47011c14bc9ba433358f4334c88')

# Adiciona o DDL
try:
    vn.train(ddl=ddl)
    print("DDL treinado com sucesso.")
except Exception as e:
    print(f"Erro durante o treinamento com DDL: {e}")

# Adiciona as consultas SQL
try:
    for question, sql in sql_mapping.items():
        vn.train(sql=sql)
    print("Consultas SQL adicionadas com sucesso.")
except Exception as e:
    print(f"Erro ao adicionar consultas SQL: {e}")

# Inicializa o Flask app para o Vanna
try:
    app = VannaFlaskApp(vanna=vn)  # Verifique se 'vanna' é um argumento esperado
    app.run()
except TypeError as e:
    print(f"Erro ao inicializar o Flask app: {e}")

# Fecha o cursor e a conexão
curs.close()
conn.close()

# Finaliza a JVM
jpype.shutdownJVM()
